﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Lcgms.WebAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddCors(options =>
            {
                options.AddDefaultPolicy(builder =>
                {
                    builder.WithOrigins("*");
                });
            });
            services.AddResponseCaching();
            //services.AddMvc(options =>
            //{
            //    options.CacheProfiles.Add("Minute", new CacheProfile()
            //    {
            //        Duration = 60 // 1 Minute
            //    });
            //    options.CacheProfiles.Add("Hourly", new CacheProfile()
            //    {
            //        Duration = 60 * 60 // 1 hour
            //    });
            //    options.CacheProfiles.Add("Weekly", new CacheProfile()
            //    {
            //        Duration = 60 * 60 * 24 * 7 // 7 days
            //    });
            //}).SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }

            app.UseCors();
            app.UseResponseCaching();

            app.UseHttpsRedirection();
            app.UseMvc();
        }
    }
}
