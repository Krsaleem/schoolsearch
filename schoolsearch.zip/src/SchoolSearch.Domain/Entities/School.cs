using System;
using SchoolSearch.Common;
using SchoolSearch.Domain.ValueObjects;

namespace SchoolSearch.Domain.Entities
{
    public class School : IAggregateRoot
    {
        public School()
        {
        }

        public string LocationCode { get; set; }

        public string DisplayName
        {
            get
            {
                if (string.IsNullOrEmpty(this.displayName))
                {
                    if (string.IsNullOrEmpty(Campus))
                    {
                        this.displayName = $"{Name} ({LocationCode})";
                    }
                    else
                    {
                        this.displayName = $"{Campus} : {Name} ({LocationCode})";
                    }
                }

                return this.displayName;
            }
        }

        public string Name { get; set; }

        public string Campus { get; set; }

        public string District { get; set; }

        public string AdministrativeDistrict { get; set; }

        public string PrimaryBuildingCode { get; set; }

        public string OptCode { get; set; }

        public Address Address { get; set; }

        public string AccessibilityCode { get; set; }

        public string AccessibilityDescription { get; set; }

        public Uri SchoolPageUri { get; set; }

        public Borough Borough { get; set; }

        public string PhoneNumber { get; set; }

        public int Size { get; set; }

        public string Grades { get; set; }

        public int ManagedBy { get; set; }

        protected string displayName;
    }
}