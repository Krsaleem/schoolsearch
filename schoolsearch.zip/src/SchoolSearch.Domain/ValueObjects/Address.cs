using System.Collections.Generic;
using SchoolSearch.Common;

namespace SchoolSearch.Domain.ValueObjects
{
    public class Address : ValueObject
    {
        public Address()
        {            
        }

        public Address(string primaryAddressLine, string stateCode, string zip)
        {
            this.PrimaryAddressLine = primaryAddressLine;
            this.StateCode = stateCode;
            this.Zip = zip;
        }

        public string PrimaryAddressLine { get; set; }
        
        public string StateCode { get; set; }

        public string Zip { get; set; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return PrimaryAddressLine;
            yield return StateCode;
            yield return Zip;
        }
    }
}