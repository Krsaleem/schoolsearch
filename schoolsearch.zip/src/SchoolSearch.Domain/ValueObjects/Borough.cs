using System.Collections.Generic;
using SchoolSearch.Common;

namespace SchoolSearch.Domain.ValueObjects
{
    public class Borough : ValueObject
    {
        public int BoroughNumber { get; set; }

        public string BoroughCode { get; set; }

        public string BoroughName { get; set; }

        protected override IEnumerable<object> GetAtomicValues()
        {
            yield return BoroughCode;
        }
    }
}