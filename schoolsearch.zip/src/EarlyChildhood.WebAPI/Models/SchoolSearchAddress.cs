﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EarlyChildhood.WebAPI.Models
{
    public class SchoolSearchAddress
    {
        public virtual string locationCode { get; set; }
        public virtual string name { get; set; }
        public virtual string primaryAddressLine { get; set; }
        public virtual string dataflag { get; set; }
    }
}
