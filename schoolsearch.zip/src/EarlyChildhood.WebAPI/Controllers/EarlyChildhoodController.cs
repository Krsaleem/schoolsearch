﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using EarlyChildhood.WebAPI.Models;
using EarlyChildhood.WebAPI.Utility;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Configuration;

namespace EarlyChildhood.WebAPI.Controllers
{
    [ApiController]
    [EnableCors]
    public class EarlyChildhoodController : ControllerBase
    {
        public static IConfiguration _config;
        private static NHibernate.ISession iSession;
        public EarlyChildhoodController(IConfiguration config)
        {
            _config = config;
            if (iSession is null)
            {
                iSession = NHibernateHelper.OpenSession();
            }
        }

        [HttpGet]
        [Route("")]
        public async Task<string> Get()
        {
            string sLocCode = "%%", sName = "%%", sAddress = "%%";
            string sUrl = "SearchEC:ECReturnRows:RowsGetSchools";

            try
            {
                var results = await iSession.GetNamedQuery("SchoolSearch_EL_GetSchools")
                    .SetString("sLocCode", sLocCode)
                    .SetString("sName", sName)
                    .SetString("sAddress", sAddress)
                    .SetString("sLocCodeEx1", sLocCode)
                    .SetString("sNameEx1", sName)
                    .SetString("sAddressEx1", sAddress)
                    .SetString("sLocCodeEx2", sLocCode)
                    .SetString("sNameEx2", sName)
                    .SetString("sAddressEx2", sAddress)
                    .SetString("sBorough", "%%")
                    .SetString("sGrade", "%%")
                    .SetString("sRows", GetRows(sUrl))
                    .ListAsync<SchoolSearchInfo>();
                if (results.Count() == 0)
                {
                    return string.Empty;
                }
                return JsonConvert.SerializeObject(results.OrderBy(x => x.locationCode));
                //return "\u2728";
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        [HttpGet]
        [Route("GetSchools")]
        public async Task<string> GetSchools(string search, string borough, string grade)
        {
            search = search?.Trim();
            string sUrl = "SearchEC:ECReturnRows:RowsGetSchools";
            string searchExtension0 = string.Empty, searchExtension1 = string.Empty, searchExtension2 = string.Empty;

            if (!string.IsNullOrEmpty(search))
            {
                string[] sArgs = GetParameters(search);
                searchExtension0 = "%" + sArgs[0].Replace("'", "''") + "%";
                searchExtension1 = "%" + sArgs[1].Replace("'", "''") + "%";
                searchExtension2 = "%" + sArgs[2].Replace("'", "''") + "%";
            }
            else
            {
                searchExtension0 = "%%";
                searchExtension1 = "%%";
                searchExtension2 = "%%";
            }

            borough = "%" + borough?.Trim().Replace("'", "''") + "%";
            grade = "%" + grade?.Trim().Replace("'", "''") + "%";

            try
            {
                var results = await iSession.GetNamedQuery("SchoolSearch_EL_GetSchools")
                    .SetString("sLocCode", searchExtension0)
                    .SetString("sName", searchExtension0)
                    .SetString("sAddress", searchExtension0)
                    .SetString("sLocCodeEx1", searchExtension1)
                    .SetString("sNameEx1", searchExtension1)
                    .SetString("sAddressEx1", searchExtension1)
                    .SetString("sLocCodeEx2", searchExtension2)
                    .SetString("sNameEx2", searchExtension2)
                    .SetString("sAddressEx2", searchExtension2)
                    .SetString("sBorough", borough)
                    .SetString("sGrade", grade)
                    .SetString("sRows", GetRows(sUrl))
                    .ListAsync<SchoolSearchInfo>();
                if (results.Count() == 0)
                {
                    return string.Empty;
                }
                return JsonConvert.SerializeObject(results.OrderBy(x => x.locationCode));
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
        }

        [HttpGet]
        [Route("GetByLocCodes")]
        public async Task<string> GetByLocCodes(string locationCodes)
        {
            var codes = locationCodes.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            if (string.IsNullOrEmpty(locationCodes))
            {
                codes = new string[] { "" };
            }

            try
            {
                var results = await iSession.GetNamedQuery("SchoolSearch_EL_GetByLocCodes")
                    .SetParameterList("aLocationCode", codes)
                    .ListAsync<SchoolSearchInfo>();
                if (results.Count == 0)
                {
                    return string.Empty;
                }
                return JsonConvert.SerializeObject(results);
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        [HttpGet]
        [Route("GetSchoolsBySearch")]
        public async Task<string> GetSchoolsBySearch(string search)
        {
            search = search?.Trim();
            string sUrl = "SearchEC:ECReturnRows:RowsGetSchoolsBySearch";
            string searchExtension0 = string.Empty, searchExtension1 = string.Empty, searchExtension2 = string.Empty;

            if (!string.IsNullOrEmpty(search))
            {
                string[] sArgs = GetParameters(search);
                searchExtension0 = "%" + sArgs[0].Replace("'", "''") + "%";
                searchExtension1 = "%" + sArgs[1].Replace("'", "''") + "%";
                searchExtension2 = "%" + sArgs[2].Replace("'", "''") + "%";
            }
            else
            {
                searchExtension0 = "%%";
                searchExtension1 = "%%";
                searchExtension2 = "%%";
            }

            try
            {
                IList<SchoolSearchAddress> results = await iSession.GetNamedQuery("SchoolSearch_EL_GetSchoolsBySearch")
                    .SetString("sLocCode", searchExtension0)
                    .SetString("sName", searchExtension0)
                    .SetString("sAddress", searchExtension0)
                    .SetString("sLocCodeEx1", searchExtension1)
                    .SetString("sNameEx1", searchExtension1)
                    .SetString("sAddressEx1", searchExtension1)
                    .SetString("sLocCodeEx2", searchExtension2)
                    .SetString("sNameEx2", searchExtension2)
                    .SetString("sAddressEx2", searchExtension2)
                    .SetString("sRows", GetRows(sUrl))
                    .ListAsync<SchoolSearchAddress>();
                if (results.Count == 0)
                {
                    return string.Empty;
                }
                return JsonConvert.SerializeObject(results);
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        public static string[] GetParameters (string search)
        {
            while (search.Length < 4)
            {
                search = search + " ";
            }
            string[] pattern;
            try
            {
                pattern = _config.GetValue<string>("SearchEC:Parameters:Pattern")?.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            }
            catch (Exception)
            {
                pattern = new string[] { "p.s.", "p. s", "p s.", ".ps", "p s", "ps.", "ps" };
            }

            string firstDigital = string.Empty, searchExtension1 = string.Empty, searchExtension2 = string.Empty;

            foreach (string s in pattern)
            {
                if (search.ToLower().Substring(0, 4).Contains(s))
                {
                    search = search.Replace(s, "p.s.");
                    try
                    {
                        if (Char.IsDigit(search[4]))
                        {
                            search = search.Replace("p.s.", "p.s. ");
                        }
                    }
                    catch (Exception)
                    {
                        search = search.Replace("p.s.", "p.s. ");
                    }
                    firstDigital = Regex.Match(search.Replace("p.s.", "").TrimStart(), @"^\d+").ToString();
                    switch (firstDigital.Length)
                    {
                        case 1:
                            searchExtension1 = "p.s. 00" + firstDigital;
                            searchExtension2 = "p.s. 0" + firstDigital;
                            break;
                        case 2:
                            searchExtension1 = "p.s. 0" + firstDigital;
                            searchExtension2 = search;
                            break;
                        default:
                            searchExtension1 = search;
                            searchExtension2 = search;
                            break;
                    }
                    break;
                }
            }
            if (string.IsNullOrEmpty(searchExtension1))
            {
                searchExtension1 = search;
            }
            if (string.IsNullOrEmpty(searchExtension2))
            {
                searchExtension2 = search;
            }
            string[] aSearch = { search.Trim(), searchExtension1.Trim(), searchExtension2.Trim() };
            Array.Sort(aSearch, (x, y) => x.Length.CompareTo(y.Length));
            Array.Reverse(aSearch);
            return aSearch;
        }

        public static string GetRows (string sUrl)
        {
            string sRows = string.Empty;
            try
            {
                sRows = _config.GetValue<string>(sUrl).Trim();
                if (string.IsNullOrEmpty(sRows))
                {
                    return "5";
                }
                else
                {
                    return Int32.Parse(sRows).ToString();
                }
            }
            catch (Exception)
            {
                return "5";
            }
        }
    }
}
