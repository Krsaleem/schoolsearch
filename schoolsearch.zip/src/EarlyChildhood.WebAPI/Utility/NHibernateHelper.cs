﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using NHibernate;
using NHibernate.Cfg;

namespace EarlyChildhood.WebAPI.Utility
{
    public class NHibernateHelper
    {
        private static ISessionFactory _sessionFactory;
        private static ISessionFactory SessionFactory
        {
            get
            {
                try
                {
                    if (_sessionFactory == null)
                    {
                        //Configuration configuration = new NHibernate.Cfg.Configuration().Configure();
                        Configuration configuration = new NHibernate.Cfg.Configuration().Configure(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "hibernate.xml"));
                        configuration.AddAssembly(Assembly.GetExecutingAssembly());
                        _sessionFactory = configuration.BuildSessionFactory();
                    }
                    return _sessionFactory;
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.ToString());
                    return null;
                }
                finally
                {
                    _sessionFactory.Close();
                }
            }
        }

        public static ISession OpenSession()
        {
            return SessionFactory.OpenSession();
        }
    }
}
