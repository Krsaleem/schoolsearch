﻿using System;

namespace SchoolSearch.Infrastructure
{
    public class Class1
    {
    }
}
