namespace SchoolSearch.Common
{
    public interface IEntity
    {
        // marker interface
    }
}