namespace SchoolSearch.Common
{
    public interface IAggregateRoot
    {
        // marker interface
    }
}