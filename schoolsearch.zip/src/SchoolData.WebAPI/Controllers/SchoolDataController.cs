﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SchoolData.WebAPI.Models;
using SchoolData.WebAPI.Utility;

namespace SchoolData.WebAPI.Controllers
{
    [ApiController]
    [EnableCors]
    [AllowAnonymous]
    public class SchoolDataController : ControllerBase
    {
        public static IConfiguration _config;

        public static IDistributedCache _distributedCache;
        private readonly int CacheData;
        private DistributedCacheEntryOptions _cacheOptions = new DistributedCacheEntryOptions();

        public SchoolDataController(IConfiguration config, IDistributedCache distributedCache)
        {
            _config = config;
            _distributedCache = distributedCache;

            CacheData = _config.GetValue<int>("AppUrlSettings:CacheData:Minutes");
            _cacheOptions.SetAbsoluteExpiration(TimeSpan.FromMinutes(CacheData));

        }

        [HttpGet]
        [Route("")]
        public async Task<string> Get()
        {
            string url = _config.GetValue<string>("AppUrlSettings:SchoolData:GetAddress");
            try
            {
                var task = await Utility.Utility.GetGeoXMLInfo(url, "335", "adams st", "3");
                if (task.Length > 0)
                {
                    await GetGISCache();
                    return "\u2728";
                }
                else
                {
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [HttpGet]
        [Route("GetSchools")]
        public async Task<string> GetSchools(string search, string borough, string grade)
        {
            try
            {
                var cachedObj = await GetSchooldataCache();
               
                //Convert Schools Data into List
                IList<SearchEntity> allSchools = JsonConvert.DeserializeObject<IList<SearchEntity>>(cachedObj);

                search = !string.IsNullOrEmpty(search) ? search.ToLower().Trim() : string.Empty;
                borough = !string.IsNullOrEmpty(borough) ? borough.ToLower().Trim() : string.Empty;
                grade = !string.IsNullOrEmpty(grade) ? grade.ToLower().Trim() : string.Empty;

                //Filter the Data
                IList<SearchEntity> filterSchools = Helper.FilterSchools(allSchools, search, borough, grade);

                return filterSchools.Count > 0 ? JsonConvert.SerializeObject(filterSchools) : null;

            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        [HttpGet]
        [Route("GetByLocationCodes")]
        public async Task<string> GetByLocationCodes(string locationCodes)
        {
            try
            {
                var cachedObj = await GetSchooldataCache();

                //Convert Schools Data into List
                IList<SearchEntity> allSchools = JsonConvert.DeserializeObject<IList<SearchEntity>>(cachedObj);

                //Get GIS Cache
                var cacheGIS = await GetGISCache();

                //Convert GIS Data into List
                IList<SearchEntity> GISData = JsonConvert.DeserializeObject<IList<SearchEntity>>(cacheGIS);

                var locCodesArray = locationCodes.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                //Filtering the Data
                IList<SearchEntity> filterSchools = Helper.FilterByLocCodes(allSchools, locCodesArray);

                return JsonConvert.SerializeObject(filterSchools);

            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        [HttpGet]
        [Route("GetByLocationCodesByXY")]
        public async Task<string> GetByLocationCodesByXY(string x, string y, string locationCodes)
        {
            try
            {
                var cachedObj = await GetSchooldataCache();

                //Convert Schools Data into List
                IList<SearchEntity> allSchools = JsonConvert.DeserializeObject<IList<SearchEntity>>(cachedObj);

                //Get GIS Cache
                var cacheGIS = await GetGISCache();

                //Convert GIS Data into List
                IList<SearchEntity> GISData = JsonConvert.DeserializeObject<IList<SearchEntity>>(cacheGIS);

                var locCodesArray = locationCodes.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                //Filtering the Data
                IList<SearchEntity> filterSchools = Helper.FilterByLocCodes(allSchools, locCodesArray);

                //Update Distance in Filter Schools
                IList<SearchEntity> schools = Helper.UpdateDistance(filterSchools, x, y);

                return JsonConvert.SerializeObject(schools.OrderBy(item => Convert.ToDouble(item.distance)));

            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        [HttpGet]
        [Route("GetSchoolsBySearch")]
        public async Task<string> GetSchoolsBySearch(string search)
        {
            try
            {
                var cachedObj = await GetSchooldataCache();

                //Convert Schools Data into List
                IList<SearchEntity> allSchools = JsonConvert.DeserializeObject<IList<SearchEntity>>(cachedObj);

                search = !string.IsNullOrEmpty(search) ? search.ToLower().Trim() : string.Empty;

                var filterResuls = new List<SearchEntity>();

                if (!string.IsNullOrEmpty(search))
                {
                    string[] pSearch = Helper.GetParameters(search);
                    filterResuls = allSchools.Where(x => x.locationCode.ToLower().Contains(pSearch[0]) ||
                                   x.primaryAddressLine.ToLower().Contains(pSearch[0]) ||
                                   x.name.ToLower().Contains(pSearch[0]) ||
                                   x.locationCode.ToLower().Contains(pSearch[1]) ||
                                   x.primaryAddressLine.ToLower().Contains(pSearch[1]) ||
                                   x.name.ToLower().Contains(pSearch[1]) ||
                                   x.locationCode.ToLower().Contains(pSearch[2]) ||
                                   x.primaryAddressLine.ToLower().Contains(pSearch[2]) ||
                                   x.name.ToLower().Contains(pSearch[2])
                                   ).Distinct().Take(5).ToList();


                }

                var EClist = filterResuls.Where(x => x.dataflag == "C").ToList();

                var LCGMSList = filterResuls.Where(x => x.dataflag != "C").ToList();

                List<SearchEntity> filterSchools = Helper.GetMergeDataBySearch(EClist, LCGMSList);

                return JsonConvert.SerializeObject(filterSchools);

            }
            catch (Exception)
            {
                return null;
            }
        }

        [HttpGet]
        [Route("GetAddress")]
        public async Task<string> GetAddress(string houseNumber, string streetName, string boroughOrZipCode)
        {
            houseNumber = !string.IsNullOrEmpty(houseNumber) ? houseNumber.Trim() : string.Empty;
            streetName = !string.IsNullOrEmpty(streetName) ? streetName.Trim() : string.Empty;
            boroughOrZipCode = !string.IsNullOrEmpty(boroughOrZipCode) ? boroughOrZipCode.Trim() : string.Empty;


            string APIURL = _config.GetValue<string>("AppUrlSettings:SchoolData:GetAddress");
            string boroughName = Utility.Utility.ToBoroughName(boroughOrZipCode);

            //If cache Is not empty
            var cacheKey = "GetAddress" + "_" + houseNumber + "_" + streetName + "_" + boroughOrZipCode;
            var cachedObj = await _distributedCache.GetStringAsync(cacheKey);

            if (string.IsNullOrEmpty(cachedObj))
            {
                List<GeoSupportInfo> geoList = new List<GeoSupportInfo>();

                //If brough selected
                if (!string.IsNullOrEmpty(boroughOrZipCode))
                {
                    //Call API
                    var geoXml = await Utility.Utility.GetGeoXMLInfo(APIURL, houseNumber, streetName, boroughOrZipCode);

                    if (geoXml.Length > 0)
                    {
                        geoList.Add(new GeoSupportInfo()
                        {
                            address = houseNumber + " " + streetName + ", " + boroughName,
                            x = Utility.Utility.GetValueBetweenStrings(geoXml, "<X>", "</X>"),
                            y = Utility.Utility.GetValueBetweenStrings(geoXml, "<Y>", "</Y>"),
                            geoInfo = JsonConvert.DeserializeObject(Utility.Utility.Xml2Json("<SchoolInfo><CurrentYear>" + Utility.Utility.GetValueBetweenStrings(geoXml, "<CurrentYear>", "</CurrentYear>") + "</CurrentYear><NextYear>" + Utility.Utility.GetValueBetweenStrings(geoXml, "<NextYear>", "</NextYear>") + "</NextYear></SchoolInfo>"))
                        });

                        //saving Cache
                        _distributedCache.SetString(cacheKey, JsonConvert.SerializeObject(geoList), _cacheOptions);
                    }
                }
                else
                {
                    foreach (var pair in Utility.Utility.BoroughMap())
                    {
                        //Call API
                        var geoXml = await Utility.Utility.GetGeoXMLInfo(APIURL, houseNumber, streetName, pair.Key);

                        if (geoXml.Length > 0)
                        {
                            geoList.Add(new GeoSupportInfo()
                            {
                                address = houseNumber + " " + streetName + ", " + pair.Value,
                                x = Utility.Utility.GetValueBetweenStrings(geoXml, "<X>", "</X>"),
                                y = Utility.Utility.GetValueBetweenStrings(geoXml, "<Y>", "</Y>"),
                                geoInfo = JsonConvert.DeserializeObject(Utility.Utility.Xml2Json("<SchoolInfo><CurrentYear>" + Utility.Utility.GetValueBetweenStrings(geoXml, "<CurrentYear>", "</CurrentYear>") + "</CurrentYear><NextYear>" + Utility.Utility.GetValueBetweenStrings(geoXml, "<NextYear>", "</NextYear>") + "</NextYear></SchoolInfo>"))
                            });
                        }
                    }

                    //saving Cache
                    _distributedCache.SetString(cacheKey, JsonConvert.SerializeObject(geoList), _cacheOptions);
                }
            }

            var geoCache = await _distributedCache.GetStringAsync(cacheKey);
            string geoResult = JsonConvert.SerializeObject(geoCache);

            return (string.IsNullOrEmpty(geoResult) || geoResult == "[]") ? string.Empty : geoCache;
        }

        private async Task<string> GetSchooldataCache()
        {
            var cachedObj = await _distributedCache.GetStringAsync("AllSchools");

            if (string.IsNullOrEmpty(cachedObj) || cachedObj == "[]")
            {
                string urlEC = _config.GetValue<string>("AppUrlSettings:EarlyChildhood:GetSchools");
                string urlLcgms = _config.GetValue<string>("AppUrlSettings:LcgmsSchoolSearch:GetSchools");

                //LCGMS Data API Call
                var ECData = await Utility.Utility.GetResponseByAPI(urlEC, string.Empty);

                //EarlyChildhood Data API Call
                var LCGMSData = await Utility.Utility.GetResponseByAPI(urlLcgms, string.Empty);

                //Get GIS Data from Cache
                IList<SearchEntity> gisData = JsonConvert.DeserializeObject<IList<SearchEntity>>(await GetGISCache());

                //Meger the LCGMS and EC Data
                IList<SearchEntity> mergeSchools = JsonConvert.DeserializeObject<IList<SearchEntity>>(Helper.GetMergeLCGMSEC(ECData, LCGMSData, _config));

                //Update Cooridnates from GIS (X, Y)
                IList<SearchEntity> dbResults = Helper.UpdateCordinates(mergeSchools, gisData);

                //Convert List into string
                string strList = JsonConvert.SerializeObject(dbResults);

                //Saving in the Cache
                _distributedCache.SetString("AllSchools", strList, _cacheOptions);

                return strList;
            }

            return cachedObj;
        }

        [ResponseCache(CacheProfileName = "Minute")]
        [Route("GISSchools")]
        public async Task<string> GetGISCache()
        {
            var cachedObj = await _distributedCache.GetStringAsync("GISSchools");

            if (string.IsNullOrEmpty(cachedObj))
            {
                NHibernate.ISession iSession = NHibernateHelper.OpenSession();

                try
                {
                    IList<SchoolSearchInfo> results = await iSession.GetNamedQuery("SchoolSearch_GIS_GetSchools").ListAsync<SchoolSearchInfo>();
                    IList<SearchEntity> gisList = JsonConvert.DeserializeObject<IList<SearchEntity>>(JsonConvert.SerializeObject(results));

                    //Saving in the Cache 
                    _distributedCache.SetString("GISSchools", JsonConvert.SerializeObject(gisList), _cacheOptions);

                    return JsonConvert.SerializeObject(gisList);
                }
                catch (Exception ex)
                {
                    return ex.Message;
                }
                finally
                {
                    iSession.Close();
                }
            }

            return cachedObj;
        }

    }
}