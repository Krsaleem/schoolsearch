﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolData.WebAPI.Models
{
    public class SchoolSearchInfo
    {
        public virtual string locationCode { get; set; }
        public virtual string type { get; set; }
        public virtual string boroughName { get; set; }
        public virtual string name { get; set; }
        public virtual string phoneNumber { get; set; }
        public virtual string primaryAddressLine { get; set; }
        public virtual string zip { get; set; }
        public virtual string grades { get; set; }
        public virtual string stateCode { get; set; }
        public virtual string x { get; set; }
        public virtual string y { get; set; }
        public virtual string profile { get; set; }
        public virtual string neighborhood { get; set; }
        public virtual string district { get; set; }
        public virtual string distance { get; set; }
        public virtual string dataflag { get; set; }
    }
}
