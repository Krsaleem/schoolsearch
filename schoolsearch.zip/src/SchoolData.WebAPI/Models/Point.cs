﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolData.WebAPI.Models
{
    public class Point
    {
        public string X { get; set; }
        public string Y { get; set; }
    }
}
