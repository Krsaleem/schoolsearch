﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolData.WebAPI.Models
{
    public class SearchAutoCompletion
    {
        public string search { get; set; }
    }
}
