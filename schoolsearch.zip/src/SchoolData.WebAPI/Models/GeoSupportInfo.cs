﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolData.WebAPI.Models
{
    public class GeoSupportInfo
    {
        public string address { get; set; }
        public string x { get; set; }
        public string y { get; set; }
        public Object geoInfo { get; set; }
    }
}
