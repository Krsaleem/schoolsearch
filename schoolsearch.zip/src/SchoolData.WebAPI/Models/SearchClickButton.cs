﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SchoolData.WebAPI.Models
{
    public class SearchClickButton
    {
        public string search { get; set; }
        public string borough { get; set; }
        public string grade { get; set; }
    }
}
