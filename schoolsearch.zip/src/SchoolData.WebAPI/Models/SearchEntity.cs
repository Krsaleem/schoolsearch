﻿using System.Runtime.Serialization;

namespace SchoolData.WebAPI.Models
{
    [DataContract]
    public class SearchEntity
    {
        [DataMember(Name = "locationCode")]
        public string locationCode { get; set; }
        [DataMember(Name = "type")]
        public string type { get; set; }
        [DataMember(Name = "boroughName")]
        public string boroughName { get; set; }
        [DataMember(Name = "boroughCode")]
        public string boroughCode { get; set; }
        [DataMember(Name = "name")]
        public string name { get; set; }
        [DataMember(Name = "phoneNumber")]
        public string phoneNumber { get; set; }
        [DataMember(Name = "primaryAddressLine")]
        public string primaryAddressLine { get; set; }
        [DataMember(Name = "zip")]
        public string zip { get; set; }
        [DataMember(Name = "grades")]
        public string grades { get; set; }
        [DataMember(Name = "stateCode")]
        public string stateCode { get; set; }
        [DataMember(Name = "x")]
        public string x { get; set; }
        [DataMember(Name = "y")]
        public string y { get; set; }
        [DataMember(Name = "profile")]
        public string profile { get; set; }
        [DataMember(Name = "neighborhood")]
        public string neighborhood { get; set; }
        [DataMember(Name = "district")]
        public string district { get; set; }
        [DataMember(Name = "distance")]
        public string distance { get; set; }
        [DataMember(Name = "dataflag")]
        public string dataflag { get; set; }
    }
}
