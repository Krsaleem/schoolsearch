﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SchoolData.WebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace SchoolData.WebAPI.Utility
{
    public static class Helper
    {
        public static IConfiguration _config;

        public static string GetMergeLCGMSEC(string elData, string lcgmsData, IConfiguration config)
        {
            if (string.IsNullOrEmpty(elData) || elData.Equals("[]")) { elData = "[]"; }
            if (string.IsNullOrEmpty(lcgmsData) || lcgmsData.Equals("[]")) { lcgmsData = "[]"; }

            IList<SearchEntity> ecList = JsonConvert.DeserializeObject<IList<SearchEntity>>(elData);
            IList<SearchEntity> lcgmsList = JsonConvert.DeserializeObject<IList<SearchEntity>>(lcgmsData);

            //FInal Return List
            List<SearchEntity> mergeList = MergeList(ecList, lcgmsList, false);

            //Get Sorting Pattern for sorting
            HashSet<string> patternHS = new HashSet<string>(Utility.GetSortPattern(config));

            //Updating the Grades Sorting
            mergeList.Where(x => !string.IsNullOrEmpty(x.grades) && x.grades.Split(',').Length > 1).ToList().ForEach(y => y.grades = Utility.GetSortGrades(y.grades, patternHS));

            return JsonConvert.SerializeObject(mergeList.OrderBy(x => x.name).ToList());
        }

        public static List<SearchEntity> GetMergeDataBySearch(List<SearchEntity> ecList, List<SearchEntity> lcgmsList)
        {
            //FInal Return List
            List<SearchEntity> mergeList = MergeList(ecList, lcgmsList, true); // True for Autocomplete

            return mergeList.OrderBy(x => x.name).ThenBy(x => x.locationCode).ToList();
        }

        public static IList<SearchEntity> UpdateCordinates(IList<SearchEntity> mergeCLList, IList<SearchEntity> gisList, string X = null, string Y = null)
        {
            var list = (from first in mergeCLList
                        join second in gisList
                        on first.locationCode equals second.locationCode
                        select new { first, second }
                       ).ToList();

            list.ForEach(item =>
            {
                item.first.x = item.second.x;
                item.first.y = item.second.y;
            });

            return list.Select(x => x.first).OrderBy(x => x.name).ToList();
        }

        public static IList<SearchEntity> UpdateDistance(IList<SearchEntity> filterSchools, string X = null, string Y = null)
        {
            filterSchools.ToList().ForEach(item =>
            {
                item.distance = Utility.GetDistance(X, Y, item.x, item.y);
            });

            filterSchools.Where(x => string.IsNullOrEmpty(x.distance)).ToList().ForEach(item => { item.distance = "1000000.00"; });

            return filterSchools;
        }

        public static List<SearchEntity> FilterSchools(IList<SearchEntity> allSchools, string search, string borough, string grade)
        {
            var filterResuls = allSchools.ToList();

            //If Seach Input is not empty
            if (!string.IsNullOrEmpty(search))
            {
                string[] pSearch = GetParameters(search);
                filterResuls = filterResuls.Where(x => x.locationCode.ToLower().Contains(pSearch[0]) ||
                               x.primaryAddressLine.ToLower().Contains(pSearch[0]) ||
                               x.name.ToLower().Contains(pSearch[0]) ||
                               x.locationCode.ToLower().Contains(pSearch[1]) ||
                               x.primaryAddressLine.ToLower().Contains(pSearch[1]) ||
                               x.name.ToLower().Contains(pSearch[1]) ||
                               x.locationCode.ToLower().Contains(pSearch[2]) ||
                               x.primaryAddressLine.ToLower().Contains(pSearch[2]) ||
                               x.name.ToLower().Contains(pSearch[2])
                               ).ToList();


            }

            //If brough Input is not empty
            if (!string.IsNullOrEmpty(borough))
            {
                filterResuls = filterResuls.Where(x => x.boroughCode.ToLower() == borough).ToList();
            }

            //If grade Input is not empty
            if (!string.IsNullOrEmpty(grade))
            {
                filterResuls = filterResuls.Where(x => x.grades.ToLower() == grade || x.grades.ToLower().Contains(grade)).ToList();
            }

            return filterResuls.OrderBy(x => x.locationCode).ToList();
        }

        public static string[] GetParameters(string search)
        {
            while (search.Length < 4)
            {
                search = search + " ";
            }

            string[] pattern;
            try
            {
                pattern = _config.GetValue<string>("SearchLcgms:Parameters:Pattern")?.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            }
            catch (Exception)
            {
                pattern = new string[] { "p.s.", "p. s", "p s.", ".ps", "p s", "ps.", "ps" };
            }

            string firstDigital = string.Empty, searchExtension1 = string.Empty, searchExtension2 = string.Empty;

            foreach (string s in pattern)
            {
                if (search.ToLower().Substring(0, 4).Contains(s))
                {
                    search = search.Replace(s, "p.s.");
                    try
                    {
                        if (Char.IsDigit(search[4]))
                        {
                            search = search.Replace("p.s.", "p.s. ");
                        }
                    }
                    catch (Exception)
                    {
                        search = search.Replace("p.s.", "p.s. ");
                    }
                    firstDigital = Regex.Match(search.Replace("p.s.", "").TrimStart(), @"^\d+").ToString();
                    switch (firstDigital.Length)
                    {
                        case 1:
                            searchExtension1 = "p.s. 00" + firstDigital;
                            searchExtension2 = "p.s. 0" + firstDigital;
                            break;
                        case 2:
                            searchExtension1 = "p.s. 0" + firstDigital;
                            searchExtension2 = search;
                            break;
                        default:
                            searchExtension1 = search;
                            searchExtension2 = search;
                            break;
                    }
                    break;
                }
            }
            if (string.IsNullOrEmpty(searchExtension1))
            {
                searchExtension1 = search;
            }
            if (string.IsNullOrEmpty(searchExtension2))
            {
                searchExtension2 = search;
            }

            string[] aSearch = { search.Trim(), searchExtension1.Trim(), searchExtension2.Trim() };
            Array.Sort(aSearch, (x, y) => x.Length.CompareTo(y.Length));
            Array.Reverse(aSearch);
            return aSearch;
        }

        public static List<SearchEntity> FilterByLocCodes(IList<SearchEntity> allSchools, string[] locCodes)
        {
            var filterResuls = new List<SearchEntity>();

            if (locCodes.Length > 0)
            {
                filterResuls = allSchools.Where(x => locCodes.Contains(x.locationCode)).ToList();
            }

            return filterResuls;
        }

        public static List<SearchEntity> MergeList(IList<SearchEntity> ecList, IList<SearchEntity> lcgmsList, bool IsAutoComplete)
        {
            //Get All Kocation COdes as Key
            HashSet<string> LCGMSLocCodes = new HashSet<string>(lcgmsList.Select(s => s.locationCode));
            HashSet<string> ECLocCodes = new HashSet<string>(ecList.Select(s => s.locationCode));

            IList<SearchEntity> sameList = null;

            //Find Match Loctions 
            if (IsAutoComplete)
            {
                sameList = (from l in lcgmsList
                            join e in ecList
                            on l.locationCode equals e.locationCode
                            select new { l, e }
                      ).Select(x => MapSearchEntityForSearch(x.l, x.e)).ToList();
            }
            else
            {
                sameList = (from l in lcgmsList
                            join e in ecList
                            on l.locationCode equals e.locationCode
                            select new { l, e }
                     ).Select(x => MapSearchEntity(x.l, x.e)).ToList();
            }

            //Unmatch EarlyChilld Data
            IList<SearchEntity> UMECList = ecList.Where(x => !LCGMSLocCodes.Contains(x.locationCode)).ToList();

            //Unmatch LCGMS Data
            IList<SearchEntity> UMLCGMSList = lcgmsList.Where(x => !ECLocCodes.Contains(x.locationCode)).ToList();

            //FInal Return List
            return sameList.Concat(UMECList).Concat(UMLCGMSList).Distinct().ToList();
        }

        public static SearchEntity MapSearchEntityForSearch(SearchEntity lcgms, SearchEntity early)
        {
            return new SearchEntity
            {
                locationCode = lcgms.locationCode,
                name = string.IsNullOrEmpty(lcgms.name) ? lcgms.name : early.name,
                primaryAddressLine = string.IsNullOrEmpty(lcgms.primaryAddressLine) ? lcgms.primaryAddressLine : early.primaryAddressLine,
                dataflag = string.IsNullOrEmpty(lcgms.district) ? lcgms.dataflag = early.dataflag : "M",
            };
        }

        public static SearchEntity MapSearchEntity(SearchEntity lcgms, SearchEntity early)
        {
            return new SearchEntity
            {
                locationCode = lcgms.locationCode,
                type = string.IsNullOrEmpty(lcgms.type) ? lcgms.type : early.type,
                boroughName = string.IsNullOrEmpty(lcgms.boroughName) ? lcgms.boroughName : early.boroughName,
                boroughCode = string.IsNullOrEmpty(lcgms.boroughCode) ? lcgms.boroughCode : early.boroughCode,
                name = string.IsNullOrEmpty(lcgms.name) ? lcgms.name : early.name,
                phoneNumber = string.IsNullOrEmpty(lcgms.phoneNumber) ? lcgms.phoneNumber : early.phoneNumber,
                primaryAddressLine = string.IsNullOrEmpty(lcgms.primaryAddressLine) ? lcgms.primaryAddressLine : early.primaryAddressLine,
                zip = string.IsNullOrEmpty(lcgms.zip) ? lcgms.zip : early.zip,
                stateCode = string.IsNullOrEmpty(lcgms.stateCode) ? lcgms.stateCode : early.stateCode,
                x = string.IsNullOrEmpty(lcgms.x) ? lcgms.x : early.x,
                y = string.IsNullOrEmpty(lcgms.y) ? lcgms.y : early.y,
                profile = string.IsNullOrEmpty(lcgms.profile) ? lcgms.profile : early.profile,
                neighborhood = string.IsNullOrEmpty(lcgms.neighborhood) ? lcgms.neighborhood : early.neighborhood,
                district = string.IsNullOrEmpty(lcgms.district) ? lcgms.district : early.district,
                distance = string.IsNullOrEmpty(lcgms.distance) ? lcgms.distance : early.distance,
                dataflag = string.IsNullOrEmpty(lcgms.district) ? lcgms.dataflag = early.dataflag : "M",
                grades = string.Join(",", lcgms.grades.Split(",").Union(early.grades.Split(",")))
            };
        }

        public static bool ContainsAny(this string haystack, IEnumerable<string> filterList)
        {
            return filterList.Any(haystack.Contains);
        }
    }
}
