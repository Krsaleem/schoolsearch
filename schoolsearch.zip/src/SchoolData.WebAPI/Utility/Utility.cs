﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Xml;

namespace SchoolData.WebAPI.Utility
{
    public static class Utility
    {
        public static HttpClientHandler handler;
        public static HttpRequestMessage request; //;
        public static HttpClient httpClient ;

        static Utility() {
            if (handler == null)
            {
                handler = new HttpClientHandler();
                handler.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
                httpClient = new HttpClient(handler, false);
                request = new HttpRequestMessage();
            }
        }

        public static string ToBoroughName(string boroughOrZipCode)
        {
            string data = string.Empty;
            switch (boroughOrZipCode.ToLower().Trim())
            {
                case "manhattan":
                case "m":
                case "1":
                    data = "Manhattan";
                    break;
                case "bronx":
                case "x":
                case "2":
                    data = "Bronx";
                    break;
                case "brooklyn":
                case "k":
                case "3":
                    data = "Brooklyn";
                    break;
                case "queens":
                case "q":
                case "4":
                    data = "Queens";
                    break;
                case "staten island":
                case "r":
                case "5":
                    data = "Staten Island";
                    break;
            }
            return data;
        }

        public static string ToBoroughNumber(string boroughOrZipCode)
        {
            string data = string.Empty;
            switch (boroughOrZipCode.ToLower().Trim())
            {
                case "1":
                case "m":
                case "manhattan":
                    data = "1";
                    break;
                case "2":
                case "x":
                case "bronx":
                    data = "2";
                    break;
                case "3":
                case "k":
                case "brooklyn":
                    data = "3";
                    break;
                case "4":
                case "q":
                case "queens":
                    data = "4";
                    break;
                case "5":
                case "r":
                case "staten island":
                    data = "5";
                    break;
            }
            return data;
        }

        public static Dictionary<string, string> BoroughMap()
        {
            Dictionary<string, string> data = new Dictionary<string, string>();
            data.Add("1", "Manhattan");
            data.Add("2", "Bronx");
            data.Add("3", "Brooklyn");
            data.Add("4", "Queens");
            data.Add("5", "Staten Island");
            return data;
        }

        public static string Xml2Json(string xmlString)
        {
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(xmlString);
                return JsonConvert.SerializeXmlNode(xmlDoc);
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        public static String GetValueBetweenStrings(String data, String start, String end)
        {
            try
            {
                int iStart = data.IndexOf(start) + start.Length;
                int iEnd = data.IndexOf(end, iStart);

                if (end == "") return (data.Substring(iStart));
                else return data.Substring(iStart, iEnd - iStart);

            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        public static async Task<string> GetGeoXMLInfo(string url, string houseNumber, string streetName, string boroughOrZipCode)
        {
            string geoResult = string.Empty;
            try
            {
                var soapRequestBody = @"<?xml version=""1.0"" encoding=""utf-8""?>  
                <soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">  
                 <soap:Body>  
                    <NYCInformationByAddress xmlns=""http://schools.nyc.gov/DOE.Services.Geography/GeoSupportService_v1_0"">
                      <HouseNumber> " + houseNumber + @"</HouseNumber>
                      <StreetName>" + streetName + @"</StreetName>
                      <BoroughOrZipCode>" + boroughOrZipCode + @"</BoroughOrZipCode>
                    </NYCInformationByAddress>
                  </soap:Body>  
                </soap:Envelope>";

                using (HttpContent httpContent = new StringContent(soapRequestBody))
                {
                    using (var request = new HttpRequestMessage(HttpMethod.Post, url))
                    {
                        request.Method = HttpMethod.Post;
                        request.Content = httpContent;
                        request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("text/xml; charset=utf-8");

                        var response = await httpClient.PostAsync(url, request.Content).ConfigureAwait(false);

                        if (response.StatusCode == HttpStatusCode.OK)
                        {
                            var stream = await response.Content.ReadAsStreamAsync().ConfigureAwait(false);
                            var content = await StreamToStringAsync(stream);
                            if (content.Length > 358)
                            {
                                geoResult = content;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
                geoResult = string.Empty;
            }
            return geoResult;
        }

        private static async Task<string> StreamToStringAsync(Stream stream)
        {
            string content = null;

            if (stream != null)
                using (var sr = new StreamReader(stream))
                    content = await sr.ReadToEndAsync();

            return content;
        }

        public static async Task<string> GetResponseByAPI(string url, string strContent)
        {
            string responseText = string.Empty;
            try
            {
                    var response = await httpClient.GetAsync(url + strContent).ConfigureAwait(false);
                    if (response.IsSuccessStatusCode)
                    {
                        var content = await response.Content.ReadAsStringAsync();
                        if (content.Length > 0) {
                            responseText = content;
                        }
                    }
            }
            catch (Exception ex)
            {
                return string.Empty;
            }
            return responseText;
        }

        public static async Task<string> PostResponseByAPI(string url, string strContent)
        {
            //byte[] postData = Encoding.ASCII.GetBytes(strContent);
            string responseText = string.Empty;
            try
            {
                using (HttpContent httpContent = new StringContent(strContent))
                {
                    using (var request = new HttpRequestMessage(HttpMethod.Post, url))
                    {
                        request.Method = HttpMethod.Post;
                        request.Content = httpContent;
                        request.Content.Headers.ContentType = MediaTypeHeaderValue.Parse("application/json");

                        var response = await httpClient.PostAsync(url, request.Content).ConfigureAwait(false);

                        if (response.StatusCode == HttpStatusCode.OK)
                        {
                            var stream = await response.Content.ReadAsStreamAsync().ConfigureAwait(false);
                            var content = await StreamToStringAsync(stream);
                            if (content.Length > 0)
                            {
                                responseText = content;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                responseText = string.Empty;
            }
            return responseText;
        }
        public static HashSet<string> GetSortPattern(IConfiguration _config)
        {
            string[] pattern;
            try
            {
                pattern = _config.GetValue<string>("AppUrlSettings:ConstantParameters:SortPattern")?.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            }
            catch (Exception ex)
            {
                pattern = new string[] { "3K", "EL", "PK", "0K", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "SE" };
            }

            return new HashSet<string>(pattern);
        }

        public static string GetDistance(string originX, string originY, string X, string Y)
        {
            try
            {
                double deltaX = Convert.ToDouble(originX) - Convert.ToDouble(X);
                double deltaY = Convert.ToDouble(originY) - Convert.ToDouble(Y);
                double distance = Math.Sqrt(deltaX * deltaX + deltaY * deltaY) * 0.000621371192;
                return Convert.ToString(distance);
            }
            catch (Exception)
            {
                return "0.00";
            }
        }

        public static string GetSortGrades(string grades, HashSet<string> pattern)
        {
            if (string.IsNullOrEmpty(grades))
            {
                return null;
            }

            var gradeArr = grades.Split(",");

            if (gradeArr.Length == 1)
            {
                return grades;
            }

            var finalarr = string.Join(",", pattern.Where(x => gradeArr.Contains(x)).ToList());

            return finalarr;
        }
    }
}
