﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace SchoolSearch.WebUI.Controllers
{
    [AllowAnonymous]
    public class HomeController : Controller
    {
        private readonly IConfiguration _configuration;

        public HomeController(IConfiguration configuration )
        {
            _configuration = configuration;
        }

        public JsonResult Index()
        {
            var asd = _configuration.GetSection("Endpoints").GetChildren();
            return Json(asd);
        }
    }
}