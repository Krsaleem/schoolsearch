﻿using System;

namespace SchoolSearch.Application
{
    public class Class1
    {
    }
}
